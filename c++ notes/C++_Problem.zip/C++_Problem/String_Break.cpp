#include<iostream>
using namespace std;
int main()
{
	char str="HelloWorld";
	char str1[6],str2[6];
	
	cout<<" "<<str;
	for(int i=0;i<str;i++)
	{
		cout<<i;			
	}	

}
