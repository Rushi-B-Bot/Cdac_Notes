package com.Student;

import java.util.Scanner;

public class Student_GetData1 {

	public Student_GetData1(int n) {
		 Studnet_DisplayData   S1[ ]= new Studnet_DisplayData [n];
		 Scanner obj = new Scanner(System.in);
		 for(int i=0;i<n;i++)
		 {
			 System.out.println("Enter Student of id " + (i + 1) + ":");
	            int id = obj.nextInt();
	            System.out.println("Enter Student of name " + (i + 1) + ":");
	            String name = obj.next();
	            System.out.println("Enter Student Addmisson Date " + (i + 1) + ":");
	            String Date = obj.next();
	            
	            S1[i]=new Studnet_DisplayData(id,name,Date);
	           
			 
		 }
		 
		 for(int i=0;i<n;i++)
		 {
			 S1[i].ShowData();
		 }

	}


    
}
