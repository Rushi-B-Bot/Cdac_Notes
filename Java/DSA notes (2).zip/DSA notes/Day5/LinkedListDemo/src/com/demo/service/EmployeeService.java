package com.demo.service;

public interface EmployeeService {

	void addnewEmp();

	void displayall();

	void displayByName(String nm);

	void deleteById(int id);

}
