package com.demo.exceptions;

public class InvalidUserEXception extends Exception{
	public InvalidUserEXception(String msg) {
		super(msg);
	}

}
