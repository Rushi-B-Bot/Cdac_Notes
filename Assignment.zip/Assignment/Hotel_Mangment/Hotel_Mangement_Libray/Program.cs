﻿using Accunt_Open1;
namespace Hotel_Menu
{
    public class Class1
    {
        static void Main(string[] args)
        {
            Accunt_Open m1 = new Accunt_Open();
            m1.run();
        }
        
    }
}
