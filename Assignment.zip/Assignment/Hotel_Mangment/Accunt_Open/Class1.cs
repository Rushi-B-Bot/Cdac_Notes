﻿namespace Accunt_Open1
{
    public class Accunt_Open
    {
        public void run()
        {

        }
    }
}
