﻿
namespace Hotel_Menu
{
    public class Menu
    {

        public void run()
        {

            Console.WriteLine("Hi");

        }
    }
}
