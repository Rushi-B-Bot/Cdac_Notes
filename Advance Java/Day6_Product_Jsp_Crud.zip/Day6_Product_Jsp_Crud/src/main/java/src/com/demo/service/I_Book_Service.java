package src.com.demo.service;

import src.com.demo.beans.Book_Data;

public interface I_Book_Service {

	int addBook(Book_Data b1);

}
