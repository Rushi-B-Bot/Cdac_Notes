package src.com.demo.dao;

import src.com.demo.beans.Book_Data;

public interface I_Book_Dao {

	int addBook(Book_Data b1);

}
