package src.com.demo.dao;

import java.util.List;

import com.demo.beans.Book_Data;

public interface I_Book_Dao {

	int addBook(Book_Data b1);

	List<Book_Data> display();

	Book_Data getbyid(int book_id);

	int updateData(Book_Data b1);


}
