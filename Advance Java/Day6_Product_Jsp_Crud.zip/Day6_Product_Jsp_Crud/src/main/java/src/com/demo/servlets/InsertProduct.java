package src.com.demo.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Book_Data;

import src.com.demo.service.Book_Service_Impl;
import src.com.demo.service.I_Book_Service;

@WebServlet("/InsertProduct")

public class InsertProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int Book_id = Integer.parseInt(request.getParameter("Book_id"));
		String Book_name = request.getParameter("Book_name");
		String BookAuthName = request.getParameter("BookAuthName");
		int Book_Qty = Integer.parseInt(request.getParameter("Book_Qty"));
		String Book_Cat = request.getParameter("Book_Cat");

		Book_Data B1 = new Book_Data(Book_id, Book_name, BookAuthName, Book_Qty, Book_Cat);
		I_Book_Service IB1 = new Book_Service_Impl();
		int n = IB1.addBook(B1);
		RequestDispatcher rd = request.getRequestDispatcher("DisplayProduct");
		rd.forward(request, response);

	}

}
