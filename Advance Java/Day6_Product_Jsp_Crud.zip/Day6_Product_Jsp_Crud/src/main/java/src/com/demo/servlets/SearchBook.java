package src.com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Book_Data;

import src.com.demo.service.Book_Service_Impl;
import src.com.demo.service.I_Book_Service;

@WebServlet("/SearchBook")
public class SearchBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter write = response.getWriter();
		int Book_id = Integer.parseInt(request.getParameter("Book_id"));
		I_Book_Service I1 = new Book_Service_Impl();
		Book_Data B1 = I1.getbyid(Book_id);
		System.out.println(B1);

		if (B1 != null) {
			request.setAttribute("Book_Data", B1);
			RequestDispatcher rd = request.getRequestDispatcher("DisplayProduct");
			rd.forward(request, response);
		
		}
	}

}
