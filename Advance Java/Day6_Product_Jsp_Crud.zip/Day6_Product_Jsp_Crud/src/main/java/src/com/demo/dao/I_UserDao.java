package src.com.demo.dao;

public interface I_UserDao {

	boolean Auth(String email, String password) throws ClassNotFoundException;

}
