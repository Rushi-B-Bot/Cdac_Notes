package src.com.demo.dao;

import com.demo.beans.UserData;

public interface I_UserDao {

	boolean Auth(String email, String password) throws ClassNotFoundException;

	UserData authenticateUser(String email, String password);

}
