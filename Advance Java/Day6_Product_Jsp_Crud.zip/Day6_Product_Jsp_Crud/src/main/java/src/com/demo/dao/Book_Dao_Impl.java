package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Book_Data;

public class Book_Dao_Impl implements I_Book_Dao {
	static Connection conn;
	static PreparedStatement pinsert,pdisplay;
	static {
		conn = DBUtil.getMyConnection();
		try {
			pinsert = conn.prepareStatement("insert into book_sales values (?,?,?,?,?)");
			pdisplay = conn.prepareStatement("SELECT * FROM book_sales");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int addBook(Book_Data b1) {
		try {
			pinsert.setInt(1, b1.getBook_id());
			pinsert.setString(2, b1.getBook_name());
			pinsert.setString(3, b1.getBookAuthName());
			pinsert.setInt(4, b1.getBook_Qty());
			pinsert.setString(5, b1.getBook_Cat());
			return pinsert.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

	@Override
	public List<Book_Data> display() {
		try {
			ResultSet rs = pdisplay.executeQuery();
			List<Book_Data> plist = new ArrayList<Book_Data>();
			while (rs.next()) {
				Book_Data u = new Book_Data(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5));
				plist.add(u);
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
