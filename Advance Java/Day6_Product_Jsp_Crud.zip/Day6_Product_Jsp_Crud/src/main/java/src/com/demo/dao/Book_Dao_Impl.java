package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import src.com.demo.beans.Book_Data;

public class Book_Dao_Impl implements I_Book_Dao {
	static Connection conn;
	static PreparedStatement pinsert;
	static {
		conn = DBUtil.getMyConnection();
		try {
			pinsert = conn.prepareStatement("insert into book_sales values (?,?,?,?,?,?)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int addBook(Book_Data b1) {
		try {
			pinsert.setInt(1, b1.getBook_id());
			pinsert.setString(1, b1.getBook_name());
			pinsert.setString(1, b1.getBookAuthName());
			pinsert.setInt(1, b1.getBook_Qty());
			pinsert.setString(1, b1.getBook_Cat());
			pinsert.setString(1, b1.getBook_Img());
			return pinsert.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

}
