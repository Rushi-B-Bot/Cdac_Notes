package src.com.demo.beans;

public class Book_Data {

	int Book_id;
	String Book_name;
	String BookAuthName;
	int Book_Qty;
	String Book_Cat;
	String Book_Img;

	public int getBook_id() {
		return Book_id;
	}

	public Book_Data(int book_id, String book_name, String bookAuthName, int book_Qty, String book_Cat,
			String book_Img) {
		super();
		Book_id = book_id;
		Book_name = book_name;
		BookAuthName = bookAuthName;
		Book_Qty = book_Qty;
		Book_Cat = book_Cat;
		Book_Img = book_Img;
	}

	public Book_Data() {
		super();
	}

	public void setBook_id(int book_id) {
		Book_id = book_id;
	}

	public String getBook_name() {
		return Book_name;
	}

	public void setBook_name(String book_name) {
		Book_name = book_name;
	}

	public String getBookAuthName() {
		return BookAuthName;
	}

	public void setBookAuthName(String bookAuthName) {
		BookAuthName = bookAuthName;
	}

	public int getBook_Qty() {
		return Book_Qty;
	}

	public void setBook_Qty(int book_Qty) {
		Book_Qty = book_Qty;
	}

	public String getBook_Cat() {
		return Book_Cat;
	}

	public void setBook_Cat(String book_Cat) {
		Book_Cat = book_Cat;
	}

	public String getBook_Img() {
		return Book_Img;
	}

	public void setBook_Img(String book_Img) {
		Book_Img = book_Img;
	}

	@Override
	public String toString() {
		return "Book_Data [Book_id=" + Book_id + ", Book_name=" + Book_name + ", BookAuthName=" + BookAuthName
				+ ", Book_Qty=" + Book_Qty + ", Book_Cat=" + Book_Cat + ", Book_Img=" + Book_Img + "]";
	}

}
