package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserDao_Servic implements I_UserDao {

	static Connection conn;
	static PreparedStatement pst;
	static {
		conn = DBUtil.getMyConnection();
		try {
			pst = conn.prepareStatement("INSERT INTO jsp values (?,?)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean Auth(String email, String password) {

		try {

			pst.setString(1, email);
			pst.setString(2, password);
			pst.executeUpdate();
			return true;

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return true;
	}

}
