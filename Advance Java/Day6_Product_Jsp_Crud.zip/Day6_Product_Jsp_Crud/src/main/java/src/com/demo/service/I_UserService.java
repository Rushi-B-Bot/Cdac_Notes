package src.com.demo.service;

public interface I_UserService {

	boolean validuser(String email, String password) throws ClassNotFoundException;

}
