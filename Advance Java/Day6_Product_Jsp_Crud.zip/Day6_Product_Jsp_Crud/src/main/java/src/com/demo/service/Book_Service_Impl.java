package src.com.demo.service;

import java.util.List;

import com.demo.beans.Book_Data;

import src.com.demo.dao.Book_Dao_Impl;
import src.com.demo.dao.I_Book_Dao;

public class Book_Service_Impl implements I_Book_Service {

	I_Book_Dao ID1 = new Book_Dao_Impl();

	@Override
	public int addBook(Book_Data b1) {
		// TODO Auto-generated method stub
		return ID1.addBook(b1);
	}

	@Override
	public List<Book_Data> getAllProducts() {

		return ID1.display();
	}

}
