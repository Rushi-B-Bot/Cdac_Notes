package src.com.demo.service;

import src.com.demo.beans.Book_Data;
import src.com.demo.dao.Book_Dao_Impl;
import src.com.demo.dao.I_Book_Dao;

public class Book_Service_Impl implements I_Book_Service {

	I_Book_Dao ID1 = new Book_Dao_Impl();

	@Override
	public int addBook(Book_Data b1) {

		return ID1.addBook(b1);
	}

}