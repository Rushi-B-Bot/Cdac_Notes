package src.com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static Connection conn;
	final static String user = "root";
	final static String pass = "Rushikesh@5046";
	final static String url = "jdbc:mysql://localhost:3306/rushi";
	
	public static Connection getMyConnection() {
		if (conn == null) {
			try {
				// Register Driver
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				
				conn = DriverManager.getConnection(url, user,pass);
				if (conn != null) {
					System.out.println("Connection established..");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block

			}

		}
		return conn;
	}

	public static void closeMyConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

		}
	}
}
