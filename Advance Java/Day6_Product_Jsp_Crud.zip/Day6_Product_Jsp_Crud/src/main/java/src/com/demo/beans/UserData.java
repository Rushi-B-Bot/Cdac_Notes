package src.com.demo.beans;

public class UserData {

	String Email;
	String Password;
	String UserName;

	public String getEmail() {
		return Email;
	}

	public UserData(String email, String password, String userName) {
		super();
		Email = email;
		Password = password;
		UserName = userName;
	}

	public UserData() {
		super();
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	@Override
	public String toString() {
		return "UserData [Email=" + Email + ", Password=" + Password + ", UserName=" + UserName + "]";
	}

}
