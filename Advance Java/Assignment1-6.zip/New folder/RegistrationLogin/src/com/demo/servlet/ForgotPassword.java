package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Registration;
import com.demo.service.ServiceUser;
import com.demo.service.ServiceUserImpl;



public class ForgotPassword extends HttpServlet {
	

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		ServiceUser uservice=new ServiceUserImpl();
		Registration user=uservice.findQuestion(uname);
		
		out.println("<form action='checkanswer' method='post'>");
		out.println("Question : <input type='text' name='q' id='q' value='"+user.getQuestion()+"'>");
		
		out.println("<input type='hidden' name='uname' id='uname' value='"+user.getUsername()+"'>");
		
		out.println("<input type='hidden' name='ans1' id='ans1' value='"+user.getAnswer()+"'>");
		
		out.println("Answer : <input type='text' name='ans' id='ans'>");
		
		out.println("New password : <input type='password' name='npass' id='npass'>");
		
		out.println("Confirm Password : <input type='password' name='cpass' id='cpass'>");
		
		out.println("<button type='submit' name='btn' id='btn' >Change Password</button>");
		
		out.println("</form>");
		
	}

}
