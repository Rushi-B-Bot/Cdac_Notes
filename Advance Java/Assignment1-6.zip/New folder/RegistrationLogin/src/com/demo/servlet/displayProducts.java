package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Product;
import com.demo.service.ServiceProduct;
import com.demo.service.ServiceProductImpl;

public class displayProducts extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		ServiceProduct pservice = new ServiceProductImpl();
		List<Product> plist = pservice.displayAllProducts();
		
		out.println("<table border='2'><tr><th>Product Id"
				+ "<th> Name"
				+ "<th>Quantity"
				+ "<th>Price</tr> ");
		
		for(Product p : plist)
		{
			out.println("<tr><td>"+p.getPid()
					+ "<td>"+p.getPname()
					+ "<td>"+p.getQty()
					+ "<td>"+p.getPrice()+"</tr>");
		}
		
		out.println("</table>");
		
	}

}
