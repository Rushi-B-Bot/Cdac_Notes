package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Registration;
import com.demo.service.ServiceUser;
import com.demo.service.ServiceUserImpl;

public class Register extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("nm");
		String gender=request.getParameter("gender");
		String[] skills=request.getParameterValues("skill");
		String username=request.getParameter("unm");
		String password=request.getParameter("pass");
		String question=request.getParameter("que");
		String answer=request.getParameter("ans");
		
		ServiceUser rservice = new ServiceUserImpl();
		Registration r=new Registration(name,gender,username,password,question,answer,skills);
		
		boolean status = rservice.addNewUser(r);
		if(status)
		{        RequestDispatcher rd=request.getRequestDispatcher("Login.html");
			     rd.forward(request,response);   
		}
		else {
			out.println("Error Occurred");
		}
		
	}

}
