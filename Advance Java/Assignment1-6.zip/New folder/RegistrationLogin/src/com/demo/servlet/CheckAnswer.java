package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.service.ServiceUser;
import com.demo.service.ServiceUserImpl;



public class CheckAnswer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		String ans1= request.getParameter("ans1");
		String ans = request.getParameter("ans");
		String npass= request.getParameter("npass");
		String cpass = request.getParameter("cpass");
		if(ans.equals(ans1))
		{
			if(npass.equals(cpass))
			{
				ServiceUser uservice = new ServiceUserImpl();
				boolean status = uservice.changePassword(uname,npass);
				out.println("<h3>Registered new password pls login!");
			}else{
				out.println("<h3>you are not autherized to change the password pls login!");
			}
				
				
		}else {
				out.println("<h3>you are not autherized to change the password pls login!");
			}
			RequestDispatcher rd=request.getRequestDispatcher("Login.html");
			rd.include(request,response);
				
				
			}
		
	}


