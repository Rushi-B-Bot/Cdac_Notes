package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.LoginUser;
import com.demo.service.ServiceUser;
import com.demo.service.ServiceUserImpl;

public class ValidateUser extends HttpServlet {
	
public void doPost(HttpServletRequest request , HttpServletResponse response) throws IOException, ServletException
{
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	
	String uname = request.getParameter("uname");
	String pwd = request.getParameter("pwd");
	ServiceUser uservice = new ServiceUserImpl();
	LoginUser ul=uservice.validateUser(uname,pwd);
	if(ul!=null)
	{
		//out.println("Valid User");
		RequestDispatcher rd = request.getRequestDispatcher("displayProducts");
		rd.forward(request, response);
	}
	else
	{
		out.println("Invalid user! Please Try Again");
		RequestDispatcher rd = request.getRequestDispatcher("Login.html");
		rd.include(request,response);
	}
	
	
}
}
