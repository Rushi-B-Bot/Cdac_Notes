package com.demo.dao;

import com.demo.beans.LoginUser;
import com.demo.beans.Registration;

public interface DaoUser {

	LoginUser validateUser(String uname, String pwd);

	boolean addNewUser(Registration r);

	Registration findQuestion(String uname);

	boolean changePassword(String uname, String npass);

}
