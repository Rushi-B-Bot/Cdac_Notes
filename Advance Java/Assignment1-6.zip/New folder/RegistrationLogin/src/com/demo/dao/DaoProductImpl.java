package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Product;

public class DaoProductImpl implements DaoProduct{
	
	static Connection conn;
	static PreparedStatement pdisplay;
	
	
	static {
		conn=DBUtil.MakeMyConnection();
		try {
			pdisplay=conn.prepareStatement("Select * from Product");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Product> displayAllProducts() {
		try {
			ResultSet rs=pdisplay.executeQuery();
			List<Product> plst = new ArrayList<>();
			while(rs.next()) {
				Product p=new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4));
				plst.add(p);
			}
			return plst;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
