package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.LoginUser;
import com.demo.beans.Registration;

public class DaoUserImpl implements DaoUser{
	
	static Connection conn;
	static PreparedStatement pvalidate,paddnewuser,pinsertuser,pselectque,pchangepass;
	
	static {
		conn=DBUtil.MakeMyConnection();
		try {
			pvalidate = conn.prepareStatement("select username,password,role from user where username=? and password=?");
		    paddnewuser=conn.prepareStatement("insert into registration values(?,?,?,?,?,?,?)");
		    pinsertuser=conn.prepareStatement("insert into user(username,password,role) values(?,?,'user')");
		    pselectque=conn.prepareStatement("select username,question,answer from registration where username=?");
		    pchangepass = conn.prepareStatement("update user set password = ? where username = ?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	@Override
	public LoginUser validateUser(String uname, String pwd) {
		try {
			pvalidate.setString(1, uname);
			pvalidate.setString(2, pwd);
			ResultSet rs = pvalidate.executeQuery();
			while(rs.next())
			{
				LoginUser l = new LoginUser(rs.getString(1),rs.getString(2),rs.getString(3));
				System.out.println(l);
				return l;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public boolean addNewUser(Registration r) {
		try {
			paddnewuser.setString(1,r.getName());
			paddnewuser.setString(2,r.getGender());
			paddnewuser.setString(3,r.getSkills()[0]);
			paddnewuser.setString(4,r.getSkills()[1]);
			paddnewuser.setString(5,r.getUsername());
			paddnewuser.setString(6,r.getQuestion());
			paddnewuser.setString(7,r.getAnswer());
			paddnewuser.executeUpdate();
			pinsertuser.setString(1,r.getUsername());
			pinsertuser.setString(2, r.getPassword());
			pinsertuser.executeUpdate();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}


	@Override
	public Registration findQuestion(String uname) {
		
		try {
			pselectque.setString(1, uname);
			ResultSet rs = pselectque.executeQuery();
			if(rs.next()) {
				Registration r = new Registration(rs.getString(1),rs.getString(2),rs.getString(3));
				return r;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public boolean changePassword(String uname, String npass) {
		try {
			pchangepass.setString(2, uname);
			pchangepass.setString(1, npass);
			pchangepass.executeUpdate();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
