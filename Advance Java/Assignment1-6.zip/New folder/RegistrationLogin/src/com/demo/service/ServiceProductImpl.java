package com.demo.service;

import java.util.List;

import com.demo.beans.Product;
import com.demo.dao.DaoProduct;
import com.demo.dao.DaoProductImpl;

public class ServiceProductImpl implements ServiceProduct{
	
	private DaoProduct pdao;
	
	public ServiceProductImpl() {
		pdao=new DaoProductImpl();
	}

	@Override
	public List<Product> displayAllProducts() {
		
		return pdao.displayAllProducts();
	}

}
