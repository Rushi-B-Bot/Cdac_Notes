package com.demo.service;

import com.demo.beans.LoginUser;
import com.demo.beans.Registration;

public interface ServiceUser {

	LoginUser validateUser(String uname, String pwd);

	boolean addNewUser(Registration r);

	Registration findQuestion(String uname);

	boolean changePassword(String uname, String npass);

	

}
