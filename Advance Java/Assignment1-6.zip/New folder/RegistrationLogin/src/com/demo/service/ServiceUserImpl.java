package com.demo.service;

import com.demo.beans.LoginUser;
import com.demo.beans.Registration;
import com.demo.dao.DaoUser;
import com.demo.dao.DaoUserImpl;

public class ServiceUserImpl implements ServiceUser{
	
	private DaoUser udao;
	
	public ServiceUserImpl()
	{
		udao=new DaoUserImpl();
	}

	

	@Override
	public LoginUser validateUser(String uname, String pwd) {
	
		return udao.validateUser(uname,pwd);
	}



	@Override
	public boolean addNewUser(Registration r) {
		
		return udao.addNewUser(r);
	}



	@Override
	public Registration findQuestion(String uname) {
		
		return udao.findQuestion(uname);
	}



	@Override
	public boolean changePassword(String uname, String npass) {
		// TODO Auto-generated method stub
		return udao.changePassword(uname,npass);
	}

}
