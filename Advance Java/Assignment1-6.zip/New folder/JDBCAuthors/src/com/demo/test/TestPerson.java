package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Person;
import com.demo.service.ServicePerson;
import com.demo.service.ServicePersonImpl;

public class TestPerson {

	public static void main(String[] args) {
		
		ServicePerson aservice = new ServicePersonImpl();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do
		{
			System.out.println(" 1.Add new Book \n2.Display All books \n3.Update Book \n4.Display by ID ");
			System.out.println("5.Delete a book by Id \n6.display by Book Name \n7.Display by Author Name");
			System.out.println("8.Exit");
			System.out.println("Enter Your Choice");
			choice = sc.nextInt();
			
			
			switch(choice) {
				case 1:
					aservice.addAuthor();
					break;
					
				case 2:
					List<Person> alist = aservice.displayAll();
					alist.forEach(System.out::println);
					break;
					
				case 3:
					
					break;
					
				case 4:
					
					break;
					
				case 5:
					
					break;
					
				case 6:
					break;
					
				case 7:
					break;
					
				case 8:
					break;
					
				default:
					System.out.println("wrong Choice");
					break;
					
					
			}
			
			
		}while(choice!=8);
		

	}

}
