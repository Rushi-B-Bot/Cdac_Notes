package com.demo.dao;

import java.util.List;

import com.demo.beans.Person;

public interface DaoPerson {

	void addNewAuthor(Person a);

	List<Person> displayAll();

	
	
}
