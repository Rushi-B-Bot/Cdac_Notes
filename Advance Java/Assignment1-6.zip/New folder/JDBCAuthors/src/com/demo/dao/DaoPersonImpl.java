package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Person;

public class DaoPersonImpl implements DaoPerson {
	
	static Connection conn;
	static PreparedStatement minsert,mselect; 
	
	
	static {
		conn= DBUtil.addMyConnection();
		try {
			minsert = conn.prepareStatement("Insert into authors values(?,?,?)");
			mselect = conn.prepareStatement("Select * from authors");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	@Override
	public void addNewAuthor(Person a) {
		
		try {
			minsert.setInt(1, a.getId());
			minsert.setString(2, a.getName());
			minsert.setString(3, a.getBook_name());
			
			int n = minsert.executeUpdate();
			if(n>0) {
				System.out.println("Inserted SuccessFully");
			}
			else {
				System.out.println("Error Occurred");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public List<Person> displayAll() {
		
		try {
			ResultSet rset = mselect.executeQuery();
			List<Person> alst = new ArrayList<>();
			while(rset.next()) {
				Person a = new Person(rset.getInt(1),rset.getString(2),rset.getString(3));
				alst.add(a);
			}
			return alst;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

}
