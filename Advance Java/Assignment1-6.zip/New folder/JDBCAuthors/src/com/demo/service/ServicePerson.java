package com.demo.service;

import java.util.List;

import com.demo.beans.Person;

public interface ServicePerson {

	void addAuthor();

	List<Person> displayAll();

}
