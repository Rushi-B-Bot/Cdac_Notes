package com.demo.service;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Person;
import com.demo.dao.DaoPerson;
import com.demo.dao.DaoPersonImpl;

public class ServicePersonImpl implements ServicePerson {

	private DaoPerson adao;
	public ServicePersonImpl() {
		adao=new DaoPersonImpl();
	}
	
	
	@Override
	public void addAuthor() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Author Id");
		int id=sc.nextInt();
		System.out.println("Enter Author Name");
		String aname=sc.nextLine();
		System.out.println();
		System.out.println("Enter Authors Book Name");
		String bname=sc.nextLine();
		
		Person a = new Person(id,aname,bname);
		adao.addNewAuthor(a);
		
	}


	@Override
	public List<Person> displayAll() {
		
		return adao.displayAll();
		
	}

}
