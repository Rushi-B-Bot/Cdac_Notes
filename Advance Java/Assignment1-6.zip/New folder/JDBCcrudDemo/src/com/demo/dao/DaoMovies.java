package com.demo.dao;

import java.util.List;

import com.demo.beans.Movies;

public interface DaoMovies {

	void closeConnection();

	void addNewMovie(Movies m);

	List<Movies> displayAll();

	Movies displayById(int mid);

	Movies displayByTitle(String title);

	List<Movies> displayByCategory(String cat);

	boolean deleteById(int mid);

	List<Movies> sortbytitle();

	boolean updateMovie(int mid, String title);
	
	

}
