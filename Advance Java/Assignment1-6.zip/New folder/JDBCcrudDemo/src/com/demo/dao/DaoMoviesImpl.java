package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Movies;

public class DaoMoviesImpl implements DaoMovies{

	static Connection conn;
	static PreparedStatement minsert,mselect,mselectById,mselectByTitle,mselectByCategory
							,mdeletebyID,mselectSorted,mupdateMovie;
	
	static {
		conn = DBUtil.addMyConnection();
		try {
			minsert=conn.prepareStatement("insert into Movies values(?,?,?)");
			mselect=conn.prepareStatement("Select *from Movies");
			mselectById=conn.prepareStatement("Select * from Movies where id=?");
			mselectByTitle = conn.prepareStatement("Select * from Movies where title=?");
			mselectByCategory = conn.prepareStatement("Select * from Movies where category=?");
			mdeletebyID = conn.prepareStatement("delete from movies where id = ?");
			mselectSorted = conn.prepareStatement("select *from movies order by title");
			mupdateMovie = conn.prepareStatement("update Movies set title=? where id=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	public void closeConnection() {
	
		DBUtil.closeMyConnection();
		
	}



	@Override
	public void addNewMovie(Movies m) {
		try {
			minsert.setInt(1,m.getId());
			minsert.setString(2,m.getTitle());
			minsert.setString(3,m.getCategory());
			int n = minsert.executeUpdate();
			if(n>0)
			{
				System.out.println("Record inserted succesfullty");
			}
			else
			{
				System.out.println("Record Insert Failed!!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}



	@Override
	public List<Movies> displayAll() {
		try {
			ResultSet rs= mselect.executeQuery();
			List<Movies> mlist = new ArrayList<>();
			while(rs.next())
			{
				Movies m = new Movies(rs.getInt(1),rs.getString(2),rs.getString(3));
				mlist.add(m);
			}
			return mlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}



	@Override
	public Movies displayById(int mid) {
		try {
			mselectById.setInt(1,mid);
			ResultSet rs = mselectById.executeQuery();
			if(rs.next()) {
				Movies m = new Movies(rs.getInt(1),rs.getString(2),rs.getString(3));
				return m;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}



	@Override
	public Movies displayByTitle(String title) {
		try {
			mselectByTitle.setString(1, title);
			ResultSet rs=mselectByTitle.executeQuery();
			if(rs.next()) {
				Movies m=new Movies(rs.getInt(1),rs.getString(2),rs.getString(3));
				return m;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}



	@Override
	public List<Movies> displayByCategory(String cat) {
		try {
			mselectByCategory.setString(1, cat);
			ResultSet rs = mselectByCategory.executeQuery();
			List<Movies> mlist = new ArrayList<>();
			while(rs.next())
			{
				
				Movies m = new Movies(rs.getInt(1),rs.getString(2),rs.getString(3));
				mlist.add(m);
			}
			return mlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}



	@Override
	public boolean deleteById(int mid) {
		try {
			mdeletebyID.setInt(1, mid);
			int rs = mdeletebyID.executeUpdate();
			if(rs>0)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}



	@Override
	public List<Movies> sortbytitle() {
		// TODO Auto-generated method stub
		try {
			ResultSet rs = mselectSorted.executeQuery();
			List<Movies> mlist = new ArrayList<>();
			while(rs.next())
			{
				
				Movies m = new Movies(rs.getInt(1),rs.getString(2),rs.getString(3));
				mlist.add(m);
			}
			return mlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}



	@Override
	public boolean updateMovie(int mid, String title) {
		try {
			mupdateMovie.setInt(2, mid);
			mupdateMovie.setString(1, title);
			int n = mupdateMovie.executeUpdate();
			if(n>0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
