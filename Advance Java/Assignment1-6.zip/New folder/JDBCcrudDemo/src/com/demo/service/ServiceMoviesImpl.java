package com.demo.service;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Movies;
import com.demo.dao.DaoMovies;
import com.demo.dao.DaoMoviesImpl;

public class ServiceMoviesImpl implements ServiceMovies{

	private DaoMovies mdao; 
	
	public ServiceMoviesImpl()
	{
		mdao=new DaoMoviesImpl();
	}
	
	
	
	@Override
	public void closeConnection() {
		
		mdao.closeConnection();
		
	}



	@Override
	public void addMovie() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Movie ID: ");
		int mid = sc.nextInt();
		System.out.println("Enter Movie title: ");
		String name=sc.next();
		System.out.println("Enter Movie category: ");
		String cat =  sc.next();
		
		Movies m = new Movies(mid,name,cat);
		mdao.addNewMovie(m);
		
		
		
	}



	@Override
	public List<Movies> displayAll() {
		
		return mdao.displayAll();
	}



	@Override
	public Movies displayByid(int mid) {
		
		return mdao.displayById(mid);
	}



	@Override
	public Movies displayByTitle(String title) {
		
		return mdao.displayByTitle(title);
	}



	@Override
	public List<Movies> displayByCategory(String cat) {
		
		return mdao.displayByCategory(cat);
	}



	@Override
	public boolean deleteById(int mid) {
		
		return mdao.deleteById(mid);
	}



	@Override
	public List<Movies> sortbytitle() {
		// TODO Auto-generated method stub
		return mdao.sortbytitle();
	}



	@Override
	public boolean updateMovie(int mid, String title) {
		
		return mdao.updateMovie(mid,title);
	}

}
