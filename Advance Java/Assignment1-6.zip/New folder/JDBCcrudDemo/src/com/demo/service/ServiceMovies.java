package com.demo.service;

import java.util.List;

import com.demo.beans.Movies;

public interface ServiceMovies {

	void closeConnection();

	void addMovie();

	List<Movies> displayAll();

	Movies displayByid(int mid);

	Movies displayByTitle(String title);

	List<Movies> displayByCategory(String cat);

	boolean deleteById(int mid);

	List<Movies> sortbytitle();

	boolean updateMovie(int mid, String title);

}
