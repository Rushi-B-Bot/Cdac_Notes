package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Movies;
import com.demo.service.ServiceMovies;
import com.demo.service.ServiceMoviesImpl;

public class TestMovies {

	public static void main(String[] args) {
		
		ServiceMovies mservice = new ServiceMoviesImpl();
		Scanner sc = new Scanner(System.in);
		int choice=0;
		do {
			System.out.println("1.Add new Movie \n2.Display All \n3.display by Id");
			System.out.println("4.Display by title \n5.Display by Category \n6.delete by Id");
			System.out.println("7.Sort by Title \n8.Update Movie Title \n9.Exit");
			System.out.println("Enter Your Choice");
			choice=sc.nextInt();
			
			switch(choice) {
					case 1:
						mservice.addMovie();
						break;
						
					case 2:
						
						List<Movies> mlist = mservice.displayAll();
						mlist.forEach(System.out::println);
						break;
						
					case 3:
						System.out.println("Enter Movie Id to display");
						int mid = sc.nextInt();
						Movies m = mservice.displayByid(mid);
						if(m!=null) {
							System.out.println(m);
						}else {
							System.out.println("Not Found");
						}
						break;
						
					case 4:
						System.out.println("Enter Movie Tiyle to display");
						String title=sc.next();
						m=mservice.displayByTitle(title);
						if(m!=null) {
							System.out.println(m);
						}else {
							System.out.println("Not Found");
						}
						break;
						
					case 5:
						System.out.println("Enter Movie Category to display");
						String cat = sc.next();
						mlist = mservice.displayByCategory(cat);
						mlist.forEach(System.out::println);
						break;
						
					case 6:
						System.out.println("Enter Movie id to delete: ");
						mid = sc.nextInt();
						boolean status = mservice.deleteById(mid);
						if(status)
						{
							System.out.println("Movie deleted Succesfully");
						}
						else
						{
							System.out.println("Deletion Failed!");
						}
						break;
						
					case 7:
						List<Movies> mlst= mservice.sortbytitle();
						mlst.forEach(System.out::println);
						
						break;
						
					case 8:
						System.out.println("Enter Movie Id which you want to update");
						mid=sc.nextInt();
						System.out.println("Enter updated Movie Title");
						title=sc.next();
						
						status=mservice.updateMovie(mid,title);
						if(status) {
							System.out.println("Updated Successfully");
						}else {
							System.out.println("Error Ocurred");
						}
						break;
						
					case 9:
						System.out.println("Thank You");
						sc.close();
						mservice.closeConnection();
						break;
						
					default:
						System.out.println("Wrong Choice");
						break;
			}
			
		}while(choice!=9);

	}

}
