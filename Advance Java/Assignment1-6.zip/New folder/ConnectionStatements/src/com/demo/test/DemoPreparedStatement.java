package com.demo.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.demo.dao.DBUtil;

public class DemoPreparedStatement {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		try {
			Connection conn = DBUtil.getMyConnection();
			PreparedStatement ps = conn.prepareStatement("Select *from Branch");
			displayData(ps);
			
			PreparedStatement ps1 = conn.prepareStatement("Select * from branch where id=?");
			System.out.println("Enter Id to display");
			int id=sc.nextInt();
			ps1.setInt(1, id);
			ResultSet rs = ps1.executeQuery();
			while(rs.next())
			{
				System.out.println("ID: "+rs.getInt(1));
				System.out.println("Branch Name: "+rs.getString(2));
				System.out.println("Location: "+rs.getString(3));
				System.out.println("-----------------------------");
			}
			
			PreparedStatement ps2 =conn.prepareStatement("insert into branch values(?,?,?)");
			System.out.println("Enter Branch id");
			id=sc.nextInt();
			System.out.println("Enter Branch Name");
			String name=sc.next();
			System.out.println("Enter Branch location");
			String loc=sc.next();
			
			ps2.setInt(1, id);
			ps2.setString(2, name);
			ps2.setString(3, loc);
			int n=ps2.executeUpdate();
			if(n>0) {
				System.out.println("inserted");
			}
			displayData(ps2);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void displayData(Statement st) {
		ResultSet rs;
		try {
			rs = st.executeQuery("Select * from branch");
			while(rs.next())
			{
				System.out.println("ID: "+rs.getInt(1));
				System.out.println("Branch Name: "+rs.getString(2));
				System.out.println("Location: "+rs.getString(3));
				System.out.println("-----------------------------");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}


}
