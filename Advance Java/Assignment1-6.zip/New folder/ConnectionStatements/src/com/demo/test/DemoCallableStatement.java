package com.demo.test;

import java.sql.Connection;

import com.demo.dao.DBUtil;
import com.mysql.cj.jdbc.CallableStatement;

public class DemoCallableStatement {

	public static void main(String[] args) {
		Connection conn = DBUtil.getMyConnection();
		//CallableStatement cs = conn.prepareCall("{call getcnt(?,?)}");
		//cs.setString(1, "");
		
	}

}
