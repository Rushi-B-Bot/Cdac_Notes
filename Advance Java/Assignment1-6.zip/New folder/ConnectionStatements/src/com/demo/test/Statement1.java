package com.demo.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.demo.dao.DBUtil;


public class Statement1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Connection conn=DBUtil.getMyConnection();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select *from branch");
			while(rs.next())
			{
				System.out.println("ID: "+rs.getInt(1));
				System.out.println("Branch Name: "+rs.getString(2));
				System.out.println("Location: "+rs.getString(3));
				System.out.println("-----------------------------");
			}
			/*
			 * System.out.println("Enter Branch ID: "); int id=sc.nextInt();
			 * System.out.println("Enter Branch name: "); String name=sc.next();
			 * System.out.println("Enter Branch location: "); String loc=sc.next(); String s
			 * = "Insert into Branch Values("+id+",'"+name+"','"+loc+"')";
			 * System.out.println("Query-->"+s); int n = st.executeUpdate(s); if(n>0) {
			 * System.out.println("Insert: "); } ResultSet rs1 =
			 * st.executeQuery("select *from branch"); while(rs1.next()) {
			 * System.out.println("ID: "+rs1.getInt(1));
			 * System.out.println("Branch Name: "+rs1.getString(2));
			 * System.out.println("Location: "+rs1.getString(3));
			 * System.out.println("-----------------------------"); }
			 */
			
			String s1="xxx' or '1' = '1";
			String query = "select *from branch where branch_name='"+s1+"'";
			System.out.println(query);
			ResultSet rs2 = st.executeQuery(query);
			while(rs2.next())
			{
				System.out.println("ID: "+rs2.getInt(1));
				System.out.println("Branch Name: "+rs2.getString(2));
				System.out.println("Location: "+rs2.getString(3));
				System.out.println("*********************************");
			}	
			
			
			
			
			  //Update Records 
			System.out.println("Which id is to be updated"); 
			  int id=sc.nextInt(); 
			  System.out.println("Enter Branch name to be udated"); 
			  String name=sc.next(); 
			  String query1 ="update branch set branch_name= '"+name+"' where id="+id;
			  System.out.println("Query is -->"+query1); 
			  int n=st.executeUpdate(query1);
			  if(n>0)
			  { 
				  System.out.println("Updated"); 
			  } 
			  ResultSet
			  rs3=st.executeQuery("Select * from branch"); 
			  while(rs3.next()) {
				  System.out.println("ID: "+rs3.getInt(1));
				  System.out.println("Branch Name: "+rs3.getString(2));
				  System.out.println("Location: "+rs3.getString(3));
				  System.out.println("----------------------------------------"); 
			}
			 
			
			
			
			//Delete record
			System.out.println("Enter ID to be deleted: ");
			int delid = sc.nextInt();
			String delQuery="delete from branch where id="+delid;
			System.out.println("Query--->"+delQuery);
			 n = st.executeUpdate(delQuery);
			if(n>0)
			{
				System.out.println("Record deleted..");
			}
			ResultSet rs4 = st.executeQuery("Select *from branch");
			while(rs4.next()) {
				System.out.println("ID: "+rs4.getInt(1));
				System.out.println("Branch Name: "+rs4.getString(2));
				System.out.println("Location: "+rs4.getString(3));
				System.out.println("----------------------------------------");
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
		}finally {
			DBUtil.closeMyConnection();
		}
	}
	}



