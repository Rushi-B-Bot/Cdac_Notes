package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static Connection conn;

	public static Connection getMyConnection() {
		if (conn == null) {
			try {
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				String URL = "jdbc:mysql://192.168.10.150:3306/dac4"; // "jdbc:mysql://localhost:3306/test"
				conn = DriverManager.getConnection(URL, "dac4", "welcome");
				if (conn != null) {
					System.out.println("Connection established..");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block

			}

		}
		return conn;
	}

	public static void closeMyConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

		}
	}
}
