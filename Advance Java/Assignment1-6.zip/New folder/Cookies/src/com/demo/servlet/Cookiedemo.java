package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookiedemo")
public class Cookiedemo extends HttpServlet {
	


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String name = request.getParameter("name");
		String btn =  request.getParameter("btn");
		RequestDispatcher rd = request.getRequestDispatcher("Cookies.html");
		switch(btn)
		{
		case "add":
			String val = request.getParameter("value");
			Cookie ck = new Cookie(name,val);
			response.addCookie(ck);
			out.println("Cookie Added");
			rd.include(request, response);
			break;
			
		case "delete":
			Cookie[] ckarr = request.getCookies();
			for(Cookie c : ckarr)
			{
				if(c.getName().equals(name))
				{
					c.setMaxAge(0);
					response.addCookie(c);
					
				}
				
				
			}out.println("Cookie Delete!!");
			rd.include(request, response);
			break;
			
		
		case "show":
			ckarr = request.getCookies();
			for( Cookie c : ckarr)
			{
				out.println(c.getName()+"------->"+c.getValue()+"<br>");
			}
			rd.include(request, response);
			break;
		}//switch
	}

}
