package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.User;

public class UserDaoImpl implements UserDao{

	static Connection conn;
	static PreparedStatement ploginuser;
	static {
		conn=DBUtil.makeNewConnection();
		try {
			ploginuser=conn.prepareStatement("select username,password,role from user where username=? and password=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public User loginUser(String uname, String pass) {
		
		try {
			ploginuser.setString(1, uname);
			ploginuser.setString(2, pass);
			
			ResultSet rs = ploginuser.executeQuery();
			if(rs.next()) {
				
				User u = new User(rs.getString(1),rs.getString(2),rs.getString(3));
				return u;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
