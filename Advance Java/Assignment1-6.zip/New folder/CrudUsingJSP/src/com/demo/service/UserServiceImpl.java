package com.demo.service;

import com.demo.beans.User;
import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

public class UserServiceImpl implements UserService{

	private UserDao udao;
	
	public UserServiceImpl() {
		udao=new UserDaoImpl();
	}

	@Override
	public User loginUser(String uname, String pass) {
		
		return udao.loginUser(uname,pass);
	}
}
