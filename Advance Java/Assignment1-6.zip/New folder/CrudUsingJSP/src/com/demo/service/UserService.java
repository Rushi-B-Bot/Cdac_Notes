package com.demo.service;

import com.demo.beans.User;

public interface UserService {

	User loginUser(String uname, String pass);

}
