package com.demo.service;

import com.demo.beans.LoginUser;

public interface IUserService {

	LoginUser validateUser(String uname, String pass);

}
