package com.demo.service;

import com.demo.beans.LoginUser;
import com.demo.dao.IUserDao;
import com.demo.dao.UserDao;

public class UserService implements  IUserService {
   private IUserDao udao;
   
   public UserService() {
	   udao=new UserDao();
   }
	
	 
	@Override
	public LoginUser validateUser(String uname, String pass) {
		return udao.validateUser(uname,pass);
	}

}
