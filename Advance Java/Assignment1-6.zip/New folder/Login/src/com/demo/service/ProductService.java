package com.demo.service;

import java.util.List;

import com.demo.beans.Product;
import com.demo.dao.IProductDao;
import com.demo.dao.ProductDao;

public class ProductService implements IProductService {

	private IProductDao pdoa;
	public ProductService() {
		pdoa=new ProductDao();
	}
	
	@Override
	public List<Product> disAllProduct() {
		return pdoa.disAllProduct();
	}

}
