package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Product;

public class ProductDao implements IProductDao {

static Connection conn;
static PreparedStatement pdisplay;


static {
	conn=DBUtil.newConne();
	try {
		pdisplay=conn.prepareStatement("Select * from Product");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	
	
	@Override
	public List<Product> disAllProduct() {
		try {
			ResultSet rs=pdisplay.executeQuery();
			List<Product>plist=new ArrayList<>();
			while(rs.next()) {
				Product p=new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4));
				plist.add(p);
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

}
