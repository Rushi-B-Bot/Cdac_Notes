package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.LoginUser;

public class UserDao implements IUserDao {

	static Connection conn;
	static PreparedStatement pselect;
	
	static {
		conn=DBUtil.newConne();
		try {
			pselect = conn.prepareStatement("select username,password,role from user where username=? and password=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  
	}
	
	@Override
	public LoginUser validateUser(String uname, String pass) {
		try {
			pselect.setString(1, uname);
			pselect.setString(2, pass);
		ResultSet rs=	pselect.executeQuery();
		while(rs.next()) {
			LoginUser lg=new LoginUser(rs.getString(1) , rs.getString(2),rs.getString(3));
			System.out.println(lg);
			return lg;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

}
