package com.demo.dao;

import com.demo.beans.LoginUser;

public interface IUserDao {

	LoginUser validateUser(String uname, String pass);

}
