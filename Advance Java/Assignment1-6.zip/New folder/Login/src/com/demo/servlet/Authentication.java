package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.LoginUser;
import com.demo.service.IUserService;
import com.demo.service.UserService;

public class Authentication extends HttpServlet{
   public void doPost(HttpServletRequest request , HttpServletResponse resp) throws IOException, ServletException {
	   resp.setContentType("text/html");
	   PrintWriter out=resp.getWriter();
	   String uname=request.getParameter("uname");
	   String pass=request.getParameter("pwd");
	 
	   IUserService uservice=new UserService();
	  LoginUser ul=uservice.validateUser(uname,pass);
	  if(ul != null) {
		//  out.println("<h1>Done</h1>");
		  RequestDispatcher rd=request.getRequestDispatcher("displayProduct");
		  rd.forward(request, resp);
	  }else {
		  out.println("<h1>Not Done</h1>");
		  RequestDispatcher rd=request.getRequestDispatcher("login.html");
		  rd.include(request, resp);
	  }
	   
   }
	
	
}
