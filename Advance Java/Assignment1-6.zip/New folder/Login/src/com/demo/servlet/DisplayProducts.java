package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Product;
import com.demo.service.IProductService;
import com.demo.service.ProductService;


public class DisplayProducts extends HttpServlet{
   public void doPost(HttpServletRequest req , HttpServletResponse reps) throws IOException {
	   reps.setContentType("text/html");
	   PrintWriter out=reps.getWriter();
	   IProductService pservice=new ProductService();
	   List<Product>plist=pservice.disAllProduct();
	   
	   out.println("<table border='2'><tr><th>Product Id"
				+ "<th> Name"
				+ "<th>Quantity"
				+ "<th>Price</tr> ");
		
		for(Product p : plist)
		{
			out.println("<tr><td>"+p.getPid()
					+ "<td>"+p.getPname()
					+ "<td>"+p.getQty()
					+ "<td>"+p.getPrice()+"</tr>");
		}
		
		out.println("</table>");
   }
}
