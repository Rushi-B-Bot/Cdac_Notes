package src.com.demo.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Book_Data;

import src.com.demo.service.Book_Service_Impl;
import src.com.demo.service.I_Book_Service;

@WebServlet("/DisplayProduct")
public class DisplayProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		I_Book_Service I1 = new Book_Service_Impl();
		List<Book_Data> pList = I1.getAllProducts();

		request.setAttribute("plist", pList);

		RequestDispatcher rd = request.getRequestDispatcher("DisplayProduct.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		I_Book_Service I1 = new Book_Service_Impl();
		List<Book_Data> pList = I1.getAllProducts();

		request.setAttribute("plist", pList);

		RequestDispatcher rd = request.getRequestDispatcher("DisplayProduct.jsp");
		rd.forward(request, response);
	}

}
