package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.UserData;

public class UserDao_Servic implements I_UserDao {

	static Connection conn;
	static PreparedStatement pst, pvalid;
	static {
		conn = DBUtil.getMyConnection();
		try {
			pvalid = conn.prepareStatement("select *from jsp where Email=? and Password=?");
			pst = conn.prepareStatement("INSERT INTO jsp values (?,?)");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean Auth(String email, String password) {

		try {

			pst.setString(1, email);
			pst.setString(2, password);
			pst.executeUpdate();
			return true;

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return true;
	}

	@Override
	public UserData authenticateUser(String email, String password) {

		try {
			pvalid.setString(1, email);
			pvalid.setString(2, password);
			ResultSet rs = pvalid.executeQuery();
			if (rs.next()) {
				UserData user = new UserData(rs.getString(1), rs.getString(2));
				return user;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

}
