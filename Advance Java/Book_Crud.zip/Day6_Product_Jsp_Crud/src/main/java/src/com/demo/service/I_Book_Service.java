package src.com.demo.service;

import java.util.List;

import com.demo.beans.Book_Data;

public interface I_Book_Service {

	int addBook(Book_Data b1);

	List<Book_Data> getAllProducts();

	Book_Data getbyid(int book_id);

	int updateData(Book_Data b1);

	Book_Data searchbyid(int book_id);

	boolean DeleteById(int book_id);

}
