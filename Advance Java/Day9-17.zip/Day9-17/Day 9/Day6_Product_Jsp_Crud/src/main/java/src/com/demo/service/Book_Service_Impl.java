package src.com.demo.service;

import java.util.List;

import com.demo.beans.Book_Data;

import src.com.demo.dao.Book_Dao_Impl;
import src.com.demo.dao.I_Book_Dao;

public class Book_Service_Impl implements I_Book_Service {

	I_Book_Dao ID1 = new Book_Dao_Impl();

	public int addBook(Book_Data b1) {
		// TODO Auto-generated method stub
		return ID1.addBook(b1);
	}

	public List<Book_Data> getAllProducts() {

		return ID1.display();
	}

	public Book_Data getbyid(int book_id) {

		return ID1.getbyid(book_id);
	}

	public int updateData(Book_Data b1) {

		return ID1.updateData(b1);
	}

	@Override
	public Book_Data searchbyid(int book_id) {
		return ID1.searchbyid(book_id);
	}

	@Override
	public boolean DeleteById(int book_id) {
		// TODO Auto-generated method stub
		return ID1.DeleteById(book_id);
	}

}
