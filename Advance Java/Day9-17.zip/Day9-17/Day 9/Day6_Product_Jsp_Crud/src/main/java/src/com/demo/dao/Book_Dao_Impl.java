package src.com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Book_Data;

public class Book_Dao_Impl implements I_Book_Dao {
	static Connection conn;
	static PreparedStatement pinsert, pdisplay, pSearch, pUpdate, pdelete;
	static {
		conn = DBUtil.getMyConnection();
		try {
			pinsert = conn.prepareStatement("insert into book_sales values (?,?,?,?,?)");
			pdisplay = conn.prepareStatement("SELECT * FROM book_sales order by Book_id desc");
			pSearch = conn.prepareStatement("SELECT * FROM book_sales where Book_id=?");
			pUpdate = conn.prepareStatement(
					"update book_sales set Book_Name=?, BookAuthName= ?, Book_Qty= ?, Book_Cat= ? where  Book_id=?");

			pdelete = conn.prepareStatement("delete from book_sales where  book_id=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public int addBook(Book_Data b1) {
		try {
			pinsert.setInt(1, b1.getBook_id());
			pinsert.setString(2, b1.getBook_name());
			pinsert.setString(3, b1.getBookAuthName());
			pinsert.setInt(4, b1.getBook_Qty());
			pinsert.setString(5, b1.getBook_Cat());
			return pinsert.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

	public List<Book_Data> display() {
		try {
			ResultSet rs = pdisplay.executeQuery();
			List<Book_Data> plist = new ArrayList<Book_Data>();
			while (rs.next()) {
				Book_Data u = new Book_Data(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5));
				plist.add(u);
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public Book_Data getbyid(int book_id) {
		try {
			pSearch.setInt(1, book_id);
			ResultSet rs = pSearch.executeQuery();
			if (rs.next()) {
				Book_Data u = new Book_Data(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5));
				return u;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int updateData(Book_Data p) {
		try {
			pUpdate.setInt(5, p.getBook_id());
			pUpdate.setString(1, p.getBook_name());
			pUpdate.setString(2, p.getBookAuthName());
			pUpdate.setInt(3, p.getBook_Qty());
			pUpdate.setString(4, p.getBook_Cat());
			return pUpdate.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public Book_Data searchbyid(int book_id) {
		try {
			pSearch.setInt(1, book_id);
			ResultSet rs = pSearch.executeQuery();
			if (rs.next()) {
				Book_Data u = new Book_Data(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5));
				return u;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean DeleteById(int book_id) {
		try {
			pdelete.setInt(1, book_id);
			pdelete.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
}
