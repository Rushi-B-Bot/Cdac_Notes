package src.com.demo.service;

import com.demo.beans.UserData;

public interface I_UserService {

	boolean createuser(String email, String password) throws ClassNotFoundException;

	UserData validuser(String email, String password);

}
