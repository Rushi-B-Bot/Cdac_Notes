package com.demo.dao;

public class ProductDaoImpl {

}
